Ja fiz: botei uma imagem pra botar as infos ai dentro 
Centralizei a imagem e o título
Oq tenho que fazer ainda?
- Escrever dentro da imagem cinza.
- Pesquisar sobre mudar a cor de fundo da tela
- Ver se adiciono a imagem de matérias atrás
- ver a questão do botão pra pop up